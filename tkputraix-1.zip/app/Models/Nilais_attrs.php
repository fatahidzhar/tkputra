<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Nilais_attrs extends Model
{
    use HasFactory;

    protected $fillable = [
        'uu_attrs',
        'uu_mapel',
        'uu_class',
        'uu_kd',
        'kegiatan',
        'tanggal'
    ];
}
