<?php

namespace App\Http\Controllers;

use App\Models\Information;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InformasiWaliController extends Controller
{
    public function index()
    {
        $informasi = Information::where('status', 0)
            ->orderBy('created_at', 'desc')
            ->get();

        return view('components.Informasi', compact('informasi'));
    }

    public function show($id) {
        $informasi = Information::findOrFail($id);

        return view('components.show.Informasi', compact('informasi'));
    }
}
