<aside id="logo-sidebar"
    class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full bg-white border-r border-gray-200 sm:translate-x-0 dark:bg-gray-800 dark:border-gray-700"
    aria-label="Sidebar">
    <a href="" class="mt-5 flex justify-end ml-2 md:mr-24">
        <span class="self-center text-xl font-semibold sm:text-2xl whitespace-nowrap dark:text-white">Soon!</span>
    </a>
    <div class="h-full px-3 pb-4 pt-10  overflow-y-auto bg-white dark:bg-gray-800">
        <ul class="space-y-2">
            <?php if(Auth::user()->role == 'admin'): ?>
                <li>
                    <a href="<?php echo e(url('admin')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('admin')); ?>'"
                        class="<?php echo e(Request::is('admin') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-grid-fill text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('dataguru')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('dataguru')); ?>'"
                        class="<?php echo e(Request::is('dataguru') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-person-video3 text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Data Guru</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('datamurid')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('datamurid')); ?>'"
                        class="<?php echo e(Request::is('datamurid') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-person-heart text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Data Murid</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('kelas')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('kelas')); ?>'"
                        class="<?php echo e(Request::is('kelas') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-grid-1x2-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Kelas</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('mapel')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('mapel')); ?>'"
                        class="<?php echo e(Request::is('mapel') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-bookmark-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Mapel</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('aspek')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('aspek')); ?>'"
                        class="<?php echo e(Request::is('aspek') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-bookmarks-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Aspek KD</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('kritiksaran')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('kritiksaran')); ?>'"
                        class="<?php echo e(Request::is('kritiksaran') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-envelope-paper-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Kritik & Saran</span>
                        <span
                            class="inline-flex items-center justify-center w-3 h-3 p-3 ml-3 text-sm font-medium text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-300"><?php echo e($countkritiksaran ?? ''); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('pengaduan')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('pengaduan')); ?>'"
                        class="<?php echo e(Request::is('pengaduan') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-send-exclamation-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Pengaduan</span>
                        <span
                            class="inline-flex items-center justify-center w-3 h-3 p-3 ml-3 text-sm font-medium text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-300"><?php echo e($countpengaduan ?? ''); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('informasi')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('informasi')); ?>'"
                        class="<?php echo e(Request::is('informasi') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-bell-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Informasi</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('categori')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('categori')); ?>'"
                        class="<?php echo e(Request::is('categori') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-inboxes-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Categori</span>
                    </a>
                </li>
            <?php elseif(Auth::user()->role == 'kepsek'): ?>
                <li>
                    <a href="<?php echo e(url('kepsek')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('kepsek')); ?>'"
                        class="<?php echo e(Request::is('kepsek') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-grid-fill text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('dataguru')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('dataguru')); ?>'"
                        class="<?php echo e(Request::is('dataguru') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-person-video3 text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Data Guru</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('datamurid')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('datamurid')); ?>'"
                        class="<?php echo e(Request::is('datamurid') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-person-heart text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Data Murid</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('kelas')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('kelas')); ?>'"
                        class="<?php echo e(Request::is('kelas') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-grid-1x2-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Kelas</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('kritiksaran')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('kritiksaran')); ?>'"
                        class="<?php echo e(Request::is('kritiksaran') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-envelope-paper-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Kritik & Saran</span>
                        <span
                            class="inline-flex items-center justify-center w-3 h-3 p-3 ml-3 text-sm font-medium text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-300"><?php echo e($kritiksaran); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('pengaduan')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('pengaduan')); ?>'"
                        class="<?php echo e(Request::is('pengaduan') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-send-exclamation-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Pengaduan</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('informasi')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('informasi')); ?>'"
                        class="<?php echo e(Request::is('informasi') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-bell-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Informasi</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('categori')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('catagori')); ?>'"
                        class="<?php echo e(Request::is('categori') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-bookmark-fill text-lg ml-1 text-gray-500"></i>
                        <span class="flex-1 ml-3 whitespace-nowrap">Categori</span>
                    </a>
                </li>
            <?php elseif(Auth::user()->role == 'guru'): ?>
                <li>
                    <a href="<?php echo e(url('guru')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('guru')); ?>'"
                        class="<?php echo e(Request::is('guru') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-grid-fill text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('datamurid')); ?>"
                        onclick="event.preventDefault(); window.location.href='<?php echo e(url('datamurid')); ?>'"
                        class="<?php echo e(Request::is('datamurid') ? 'bg-gray-200' : ''); ?> flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="bi bi-person-heart text-lg ml-1 text-gray-500"></i>
                        <span class="ml-3">Data Murid</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</aside>
<?php /**PATH E:\laragon\www\tkputraix\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>