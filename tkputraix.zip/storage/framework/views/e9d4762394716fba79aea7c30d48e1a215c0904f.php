
<style>
    table,
    th,
    td {
        border: 1px solid rgb(160, 160, 160);
        border-collapse: collapse;
    }
</style>

<body>

    <?php if($start_date && $end_date): ?>
        <p>Data Rekap Absen dari <?php echo e(date('Y-m-d', strtotime($start_date))); ?> sampai
            <?php echo e(date('Y-m-d', strtotime($end_date))); ?></p>
    <?php endif; ?>

    Guru : <?php echo e(Auth::user()->full_name); ?>


    <?php
        $previousClassName = null;
    ?>

    <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->name_class != $previousClassName): ?>
            <div style="margin-bottom: 10px">
                Kelas : <?php echo e($item->name_class); ?>

            </div>
            <?php
                $previousClassName = $item->name_class;
            ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <table id="example1" class="table table-bordered table-striped" style="width:100%">
        <thead>
            <tr>
                <th scope="col">
                    No
                </th>
                <th scope="col">
                    Nama
                </th>
                <th scope="col">
                    Hadir
                </th>
                <th scope="col">
                    Izin
                </th>
                <th scope="col">
                    Sakit
                </th>
                <th scope="col">
                    Alpha
                </th>
                <th scope="col">
                    Tanggal
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                    class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <th scope="row"
                        class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white text-center">
                        <?php echo e($loop->iteration); ?>

                    </th>
                    <td class="px-6 py-4">
                        <?php echo e($item->full_name); ?>

                    </td>
                    <td align="center" class="px-9 py-4 text">
                        <?php if($item->kehadiran == 1): ?>
                            H
                        <?php endif; ?>
                    </td>
                    <td align="center" class="px-7 py-4 text">
                        <?php if($item->kehadiran == 2): ?>
                            I
                        <?php endif; ?>
                    </td>
                    <td align="center" class="px-9 py-4 text">
                        <?php if($item->kehadiran == 3): ?>
                            S
                        <?php endif; ?>
                    </td>
                    <td align="center" class="px-9 py-4 text">
                        <?php if($item->kehadiran == 4): ?>
                            A
                        <?php endif; ?>
                    </td>
                    <td align="center" class="px-9 py-4 text-center">
                        
                        <?php echo e($item->tanggal); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <table id="example1" class="table table-bordered table-striped" style="width:100%; margin-top:20px;">
        <thead>
            <tr>
                <th scope="col">
                    No
                </th>
                <th scope="col">
                    Nama
                </th>
                <th scope="col">
                    Total Hadir
                </th>
                <th scope="col">
                    Total Izin
                </th>
                <th scope="col">
                    Total Sakit
                </th>
                <th scope="col">
                    Total Alpha
                </th>
             
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                    class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <th scope="row"
                        class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white text-center">
                        <?php echo e($loop->iteration); ?>

                    </th>
                    <td class="px-6 py-4">
                        <?php echo e($item->full_name); ?>

                    </td>
                    <td align="center" class="px-9 py-4 text">
                        <?php echo e($item->total_hadir); ?>

      
                    </td>
                    <td align="center" class="px-7 py-4 text">
                        <?php echo e($item->total_izin); ?>

              
                    </td>
                    <td align="center" class="px-9 py-4 text">
                        <?php echo e($item->total_sakit); ?>

                  
                    </td>
                    <td align="center" class="px-9 py-4 text">
                        <?php echo e($item->total_alpha); ?>

                   
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</body>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tkputraix\resources\views/components/PDFRekapAbsen.blade.php ENDPATH**/ ?>