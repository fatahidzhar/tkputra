<script>
       setTimeout(function() {
       document.getElementById("sticky-banner").style.display = "none";
    }, 5000);
</script>
