<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Guru extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid_g',
        'nip',
        'nuptk',
        'address',
        'rt',
        'rw',
        'keluarahan',
        'kecamatan',
        'agama',
        'tempat_lahir',
        'tahun_lahir',
        'gender',
        'image',
        'telp',
        'jabatan',
        'tmt_kerja',
        'pend_terakhir',
        'ket',
        'tahun',
        'uu_class',
        'status'
    ];

    protected $attributes = [
        'jabatan' => 'Guru',
        'tahun' => null,
    ];

    public function __construct()
    {
        $this->attributes['tahun'] = date('Y');
    }
}
