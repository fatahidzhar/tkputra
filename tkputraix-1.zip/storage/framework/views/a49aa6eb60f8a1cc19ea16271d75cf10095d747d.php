
<?php $__env->startSection('title', 'Layanan'); ?>
<?php $__env->startSection('content'); ?>
    

    <div class="p-4">
        <a href="" onclick="event.preventDefault(); window.location.href='<?php echo e(url('layanan')); ?>'">
            <h2 class="text-3xl font-extrabold dark:text-white"><i class="bi bi-arrow-left-short mr-1"></i></h2>
        </a>
    </div>
    <div>
        <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ol class="relative border-l border-gray-200 dark:border-gray-700">
                <li class="ml-5">
                    <time
                        class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d-F Y')); ?></time>
                    <a href="<?php echo e(url('layanan/informasi/' . $item->id)); ?>">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white truncate mr-4"><?php echo e($item->title); ?>

                        </h3>
                        <p class="mb-4 mr-4 text-base font-normal text-gray-500 dark:text-gray-400">
                            <?php echo e(strlen(strip_tags($item->text)) > 100 ? substr(strip_tags($item->text), 0, 100) . '...' : strip_tags($item->text)); ?>

                        </p>
                    </a>
                </li>
            </ol>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tkputraix\resources\views/components/Informasi.blade.php ENDPATH**/ ?>