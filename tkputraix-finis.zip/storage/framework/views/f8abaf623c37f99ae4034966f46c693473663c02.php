<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.3/datepicker.turbo.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/apexcharts.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/service-worker.js')
                    .then(registration => {
                        console.log('Service worker registered:', registration);
                    })
                    .catch(error => {
                        console.log('Service worker registration failed:', error);
                    });
            });

            let deferredPrompt;
            window.addEventListener('beforeinstallprompt', (event) => {
                event.preventDefault();
                deferredPrompt = event;

                // Tampilkan pesan atau tombol instalasi di tempat yang sesuai
                const installButton = document.getElementById('install-button');
                installButton.style.display = 'block';

                installButton.addEventListener('click', () => {
                    deferredPrompt.prompt();
                    deferredPrompt.userChoice
                        .then((choiceResult) => {
                            if (choiceResult.outcome === 'accepted') {
                                console.log('Pengguna telah menginstal PWA');
                            } else {
                                console.log('Pengguna telah menolak instalasi PWA');
                            }
                            deferredPrompt = null;
                        });
                });
            });
        }
    </script>

    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }

        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }

        .disabled {
            background-color: #e5e7eb;
            border-color: #6b7280;
            color: #6b7280;
            cursor: not-allowed !important;
        }
    </style>

    <!-- Scripts -->
    <script src="<?php echo e(asset('dist/js/apexcharts.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>

<body>
    <div id="app">
        
        
        <main id="page-content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>


</body>

</html>
<?php /**PATH E:\laragon\www\tkputraix\resources\views/layouts/app.blade.php ENDPATH**/ ?>