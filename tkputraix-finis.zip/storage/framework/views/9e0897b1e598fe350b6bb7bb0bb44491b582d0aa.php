
<?php $__env->startSection('title', 'Absensi'); ?>
<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.bottomNavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="p-4 overflow-x-hidden">
        <a href="" onclick="event.preventDefault(); window.location.href='<?php echo e(url('akademik/absen')); ?>'">
            <h2 class="text-3xl mb-3 font-extrabold dark:text-white"><i class="bi bi-arrow-left-short mr-1"></i></h2>
        </a>
        <div class="flex justify-between">
            <span
                class="inline-flex items-center bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-blue-900 dark:text-blue-300">
                <span class="w-2 h-2 mr-1 bg-blue-500 rounded-full"></span>
                H : <?php echo e($persentase_hadir_formatted); ?>%
            </span>
            <span
                class="inline-flex items-center bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-green-900 dark:text-green-300">
                <span class="w-2 h-2 mr-1 bg-green-500 rounded-full"></span>
                I : <?php echo e($persentase_izin_formatted); ?>%
            </span>
            <span
                class="inline-flex items-center bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-yellow-900 dark:text-yellow-300">
                <span class="w-2 h-2 mr-1 bg-yellow-300 rounded-full"></span>
                S : <?php echo e($persentase_sakit_formatted); ?>%
            </span>
            <span
                class="inline-flex items-center bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-red-900 dark:text-red-300">
                <span class="w-2 h-2 mr-1 bg-red-500 rounded-full"></span>
                A : <?php echo e($persentase_alpa_formatted); ?>%
            </span>
        </div>
        <ul class="my-4 space-y-3">
            <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div
                        class="flex items-center p-3 text-base font-bold text-gray-900 rounded-lg bg-gray-50 hover:bg-gray-100 group dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-white">
                        <?php if($item->kehadiran == 1): ?>
                            <span class="flex w-3 h-3 bg-blue-600 rounded-full"></span>
                            <span class="flex-1 ml-3 whitespace-nowrap">Hadir</span>
                        <?php elseif($item->kehadiran == 2): ?>
                            <span class="flex w-3 h-3 bg-green-500 rounded-full"></span>
                            <span class="flex-1 ml-3 whitespace-nowrap">Izin</span>
                        <?php elseif($item->kehadiran == 3): ?>
                            <span class="flex w-3 h-3 bg-yellow-300 rounded-full"></span>
                            <span class="flex-1 ml-3 whitespace-nowrap">Sakit</span>
                        <?php elseif($item->kehadiran == 4): ?>
                            <span class="flex w-3 h-3 bg-red-500 rounded-full"></span>
                            <span class="flex-1 ml-3 whitespace-nowrap">Alpha</span>
                        <?php endif; ?>
                        <span
                            class="inline-flex items-center justify-center px-2 py-0.5 ml-3 text-xs font-medium text-gray-500 bg-gray-200 rounded dark:bg-gray-700 dark:text-gray-400"><?php echo e($item->tanggal); ?></span>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tkputraix\resources\views/components/show/AkademikAbsen.blade.php ENDPATH**/ ?>