<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
    use HasFactory;

    protected $fillable = ['uu_absen', 'uuid_g', 'uuid_m', 'kehadiran', 'tanggal'];

    public function __construct()
    {
        $this->attributes['tahun_ajaran'] = date('Y');
    }
}
