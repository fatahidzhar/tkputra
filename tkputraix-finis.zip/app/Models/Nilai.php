<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Nilai extends Model
{
    use HasFactory;

    protected $fillable = [
        'uu_nilai',
        'uu_attrs',
        'uu_mapel',
        'uuid_g',
        'uuid_m',
        'cl',
        'hk',
        'ca',
        'kegiatan',
        'tanggal'
    ];


    public function __construct()
    {
        $this->attributes['tahun_ajaran'] = date('Y');
    }
}
