<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Faq extends Model
{
    use HasFactory;

    protected $fillable = [
        'uu_categori',
        'uuid_m',
        'text',
        'status'
    ];

    public function excerpt($length = 100, $suffix = '...')
    {
        return Str::limit($this->text, $length, $suffix);
    }
}
