
<?php $__env->startSection('title', 'Nilai'); ?>
<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.bottomNavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="pt-4 pl-4 pr-2">
        <div class="flex items-center mb-2">
            <a href="" onclick="event.preventDefault(); window.location.href='<?php echo e(url('akademik')); ?>'">
                <h2 class="text-3xl font-extrabold dark:text-white"><i class="bi bi-arrow-left-short"></i></h2>
            </a>
            <span class="ml-2 text-lg font-medium">
                Tahun Ajaran Nilai
            </span>
        </div>
        <ul class="space-y-3">
            <?php $__currentLoopData = $tahun_ajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(url('akademik/nilai/' . $item->tahun_ajaran)); ?>"
                        class="flex items-center p-3 text-base font-bold text-gray-900 rounded-lg bg-gray-50 hover:bg-gray-100 group dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-white">
                        <span class="flex w-3 h-3 bg-blue-600 rounded-full"></span>
                        <span class="flex-1 ml-3 whitespace-nowrap truncate "><?php echo e($item->tahun_ajaran); ?>/<?php echo e($item->tahun_ajaran + 1); ?> <?php echo e($index %2 == 0 ? 'Ganjil' : 'Genap'); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tkputraix\resources\views/components/AkademikNilai.blade.php ENDPATH**/ ?>