
<style>
    table,
    th,
    td {
        border: 1px solid rgb(160, 160, 160);
        border-collapse: collapse;
        padding-top: 5px;
        padding-bottom: 5px;
    }
</style>

<div style="display: flex; flex-direction: column;">
    <div>
        <?php if($selected_dates): ?>
            <?php echo e($selected_dates); ?>

        <?php elseif($selected_dates != 0): ?>
            Today
        <?php endif; ?>
    </div>
    <div style="margin-top: 10px; margin-bottom: 10px;">
        <span class="flex items-center text-sm font-medium text-gray-900 dark:text-white"><span
                class="flex w-2.5 h-2.5 bg-blue-600 rounded-full mr-1.5 flex-shrink-0"></span><b>Catatan</b> : CL = CheckList,
            HK
            = Hasil Karya, CA = Catatan Anekdot, N = Nilai, NH = Nilai Hasil</span>
    </div>
</div>
<div class="relative mt-5 overflow-x-auto sm:rounded-lg">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3 bg-gray-50 dark:bg-gray-800">
                    Aspek
                </th>
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th colspan="4" class="px-6 py-3 <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        <?php echo e($mapel->mapel); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th scope="col" class="px-6 py-3 bg-gray-50 dark:bg-gray-800">
                    KD
                </th>
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th colspan="4" class="px-6 py-3 <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        <?php
                            $displayedValues = []; // Deklarasikan dan inisialisasikan di luar loop foreach
                        ?>

                        <div class="flex flex-wrap">
                            <?php $__currentLoopData = $resultsAttrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $result->{str_replace(' ', '_', $mapel->mapel) . '_uu_kd'};
                                    $filteredValue = array_unique(array_filter(explode(' ', $value)));
                                ?>

                                <?php if(!empty($filteredValue)): ?>
                                    <?php $__currentLoopData = $filteredValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!in_array($item, $displayedValues)): ?>
                                                <?php echo e($item); ?>,
                                            <?php
                                                $displayedValues[] = $item; // Tambahkan nilai ke dalam array untuk melacak nilai yang sudah ditampilkan
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th scope="col" class="px-6 py-3 bg-gray-50 dark:bg-gray-800">
                    Kegiatan
                </th>
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th colspan="4" class="px-6 py-3 <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        <div class="flex flex-wrap">
                            <?php
                                $displayedNames = []; // Array untuk melacak nama yang sudah ditampilkan
                            ?>
                            <?php $__currentLoopData = $resultsAttrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $result->{str_replace(' ', '_', $mapel->mapel) . '_uu_keg'};
                                    $filteredValue = array_filter(explode(' ', $value), function ($item) use (&$displayedNames) {
                                        $name = trim($item);
                                        if ($name === '0' || in_array($name, $displayedNames)) {
                                            return false; // Jika nilai adalah 0 atau nama sudah ditampilkan sebelumnya, jangan tampilkan
                                        } else {
                                            $displayedNames[] = $name; // Tambahkan nama ke dalam array untuk melacak nama yang sudah ditampilkan
                                            return true; // Tampilkan nama yang belum ditampilkan sebelumnya
                                        }
                                    });
                                ?>
                                <?php if(!empty($filteredValue)): ?>
                                    <?php echo e(implode(' ', $filteredValue)); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th scope="col" class="px-6 py-3 bg-gray-50 dark:bg-gray-800">
                    NH
                </th>
                <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col" class="px-3 py-3 text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        CL
                    </th>
                    <th scope="col" class="px-3 py-3 text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        HK
                    </th>
                    <th scope="col" class="px-3 py-3 text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        CA
                    </th>
                    <th scope="col" class="px-3 py-3 text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                        N</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-200 dark:border-gray-700">
                    <th scope="row"
                        class="px-6 py-4 text-gray-900 whitespace-nowrap bg-gray-50 dark:text-white dark:bg-gray-800">
                        <?php echo e($result->full_name); ?>

                    </th>
                    <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"
                            class="px-1 py-3 text-xs text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                            <?php if($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_cl'} == 0): ?>
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_cl'} == 1): ?>
                                BB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_cl'} == 2): ?>
                                MB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_cl'} == 3): ?>
                                BSH
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_cl'} == 4): ?>
                                BSB
                            <?php endif; ?>
                        </th>
                        <th scope="col"
                            class="px-1 py-3 text-xs text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                            <?php if($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_hk'} == 0): ?>
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_hk'} == 1): ?>
                                BB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_hk'} == 2): ?>
                                MB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_hk'} == 3): ?>
                                BSH
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_hk'} == 4): ?>
                                BSB
                            <?php endif; ?>
                        </th>
                        <th scope="col"
                            class="px-1 py-3 text-xs text-center <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                            <?php if($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_ca'} == 0): ?>
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_ca'} == 1): ?>
                                BB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_ca'} == 2): ?>
                                MB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_ca'} == 3): ?>
                                BSH
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_ca'} == 4): ?>
                                BSB
                            <?php endif; ?>
                        </th>
                        <th scope="col" class="px-3 text-xs py-3 <?php echo e($index % 2 == 0 ? 'bg-white' : 'bg-gray-50'); ?>">
                            <?php if($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_nh'} == 0): ?>
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_nh'} == 1): ?>
                                BB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_nh'} == 2): ?>
                                MB
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_nh'} == 3): ?>
                                BSH
                            <?php elseif($result->{str_replace(' ', '_', $mapel->mapel) . '_nilai_nh'} == 4): ?>
                                BSB
                            <?php endif; ?>
                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </tbody>
    </table>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tkputraix\resources\views/components/PDFRekap.blade.php ENDPATH**/ ?>