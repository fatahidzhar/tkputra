<script>
       setTimeout(function() {
       document.getElementById("sticky-banner").style.display = "none";
    }, 5000);
</script>
<?php /**PATH E:\laragon\www\tkputraix\resources\views/components/script/js.blade.php ENDPATH**/ ?>